﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class Email
    {
        public string EmailAddress { get; set; }
        public string Token { get; set; }
    }
}