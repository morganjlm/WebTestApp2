﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class LanguageStrings
    {
        public Dictionary<string, string> Strings { get; set; }
    }
}